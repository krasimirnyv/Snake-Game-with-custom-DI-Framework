namespace SnakeGame.Models;

public class FoodStar : Food
{
    public FoodStar(int up, int right) 
        : base(up, right)
    {
    }
}