namespace SnakeGame.Models;

public class FoodSun : Food
{
    public FoodSun(int up, int right) 
        : base(up, right)
    {
    }
}