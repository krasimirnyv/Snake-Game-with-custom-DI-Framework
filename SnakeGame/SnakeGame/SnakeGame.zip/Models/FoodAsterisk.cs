namespace SnakeGame.Models;

public class FoodAsterisk : Food
{
    public FoodAsterisk(int up, int right) 
        : base(up, right)
    {
    }
}