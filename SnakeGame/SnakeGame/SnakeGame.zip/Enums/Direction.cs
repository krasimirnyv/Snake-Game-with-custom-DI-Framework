namespace SnakeGame.Enums;

public enum Direction
{
    Up,
    Left,
    Down,
    Right
}